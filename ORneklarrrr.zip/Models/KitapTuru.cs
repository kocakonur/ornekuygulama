﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class KitapTuru
    {
        public int KitapTuruId { get; set; }
        public string KitapTuruAdi { get; set; }
        public string KitapTuruAcıklamasi { get; set; }
    }
}